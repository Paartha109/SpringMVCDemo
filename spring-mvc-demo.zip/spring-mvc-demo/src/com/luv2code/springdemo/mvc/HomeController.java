package com.luv2code.springdemo.mvc;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller //Step1
public class HomeController {
@RequestMapping("/") //step3 
	public String showPage() {   //step 2
		return "main-menu"; //"/WEB-INF/view/main-menu.jsp
	}
	
}
